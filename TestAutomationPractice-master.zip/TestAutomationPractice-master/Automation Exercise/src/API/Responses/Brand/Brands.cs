﻿namespace TestAutomationPractice.src.API.Responses.Brand
{
    public class Brands
    {
        public int Id { get; set; }
        public string Brand { get; set; }
    }
}