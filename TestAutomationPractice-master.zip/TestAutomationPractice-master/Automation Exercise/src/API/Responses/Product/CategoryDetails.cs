﻿namespace TestAutomationPractice.src.API.Responses
{
    public class CategoryDetails
    {
        public UserType UserType { get; set; }
        public string Category { get; set; }
    }
}