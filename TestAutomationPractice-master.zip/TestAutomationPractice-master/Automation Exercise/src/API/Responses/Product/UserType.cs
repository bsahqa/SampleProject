﻿namespace TestAutomationPractice.src.API.Responses
{
    public class UserType
    {
        public string UserTypeValue { get; set; }
    }
}