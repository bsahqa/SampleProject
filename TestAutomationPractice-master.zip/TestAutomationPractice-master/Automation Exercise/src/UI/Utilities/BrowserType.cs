﻿namespace TestAutomationPractice.Utilities
{
    public enum BrowserType
    {
        Chrome,
        Firefox,
        Edge
    }
}
