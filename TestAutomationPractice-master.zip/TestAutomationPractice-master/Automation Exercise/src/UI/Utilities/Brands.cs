﻿namespace TestAutomationPractice.Utilities
{
    public enum  Brands
    {
        Polo,
        HandM,
        Madame,
        MastAndHarbour,
        Babyhug,
        AllenSollyJunior,
        KookieKids,
        Biba
    }
}
