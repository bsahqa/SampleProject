﻿namespace TestAutomationPractice.Utilities
{
    public enum MonthOfYear
    {
        January,
        February,
        March,
        April,
        May,
        June,
        July,
        August,
        September,
        October,
        November,
        December
    }
}

