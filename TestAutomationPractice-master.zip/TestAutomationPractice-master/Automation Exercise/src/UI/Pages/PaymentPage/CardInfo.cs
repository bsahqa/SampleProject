﻿using TestAutomationPractice.Utilities;

namespace TestAutomationPractice.Pages.PaymentPage
{
    public class CardInfo
    {
        public string NameOnCard { get; set; }
        public string CardNumber { get; set; }
        public string CVC { get; set; }
        public string ExpirationMonth { get; set; }
        public string ExpirationYear { get; set;}

    }
}
